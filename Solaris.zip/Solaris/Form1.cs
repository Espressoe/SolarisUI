﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Controls;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Wpf;
using System.Runtime.ConstrainedExecution;
using CefSharp.WinForms;
using CefSharp;
using CefSharp.DevTools.Network;
using System.Net.Http;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net.WebSockets;
using System.Threading;
using Discord.Rest;

namespace Solaris
{
    public partial class Form1 : Form
    {
        private int currentPage = 1;
        private HttpClient httpclientthingy = new HttpClient();
        private string searchthingy = "";
        private static ClientWebSocket websocket;
        public ChromiumWebBrowser browser { get; set; }
        public ChromiumWebBrowser browser1 { get; set; }

        public Form1()
        {
            InitializeComponent();
            timer1.Start();
            InitBrowser();
            getpopular();

        }
        public string ReadScript() => CefSharp.WebBrowserExtensions.EvaluateScriptAsync((IChromiumWebBrowserBase)this.browser, "(function() { return GetText() })();", new TimeSpan?(), false).GetAwaiter().GetResult().Result.ToString();
        public void WriteScript(string script, bool tabPrompt)
        {
            CefSharp.WebBrowserExtensions.EvaluateScriptAsync((IChromiumWebBrowserBase)this.browser, "SetText(`" + script.Replace("`", "\\`").Replace("\\", "\\\\") + "`)", new TimeSpan?(), false);
        }
        private void InitBrowser()
        {
            CefSettings cefSettings = new CefSettings();
            Cef.Initialize((CefSettingsBase)cefSettings);
            this.browser = new ChromiumWebBrowser(Directory.GetCurrentDirectory() + "\\Monaco\\Monaco.html");
            this.browser1 = new ChromiumWebBrowser("https://iris-12.gitbook.io/iris-documentation/");
            this.browser.BrowserSettings.WindowlessFrameRate = 150;
            editor.Controls.Add(this.browser);
            docs.Controls.Add(this.browser1);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(exectoggle.Checked)
            {
                settings.Visible = false;
                Scripthub.Visible = false;
                executor.Visible = true;
                exec.Visible = true;
                set.Visible = false;
                sh.Visible = false;
            }
            if (scriptstoggle.Checked == true)
            {
                settings.Visible = false;
                Scripthub.Visible = true;
                executor.Visible = false;
                sh.Visible = true;
                exec.Visible = false;
                set.Visible = false;
            }
            if(settingtoggle.Checked == true)
            {
                settings.Visible = true;
                Scripthub.Visible = false;
                executor.Visible = false;
                set.Visible = true;
                exec.Visible = false;
                sh.Visible = false;
            }
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private async void getscripts()
        {
            try
            {
                flowLayoutPanel2.Controls.Clear();
                HttpResponseMessage response = await httpclientthingy.GetAsync("https://scriptblox.com/api/script/search?q=" + guna2TextBox1.Text);
                HttpContent content = response.Content;
                object dynJson = JsonConvert.DeserializeObject(await content.ReadAsStringAsync());
                foreach (dynamic item in ((dynamic)dynJson).result.scripts)
                {
                    dynamic jsonitem = JsonConvert.DeserializeObject<object>(((object)item).ToString());
                    dynamic script = Convert.ToString(jsonitem.script);
                    dynamic dastitle = Convert.ToString(jsonitem.title);
                    dynamic descthingy = Convert.ToString(jsonitem.slug);
                    flowLayoutPanel2.Controls.Add(new Script(dastitle, script));
                }
            }
            catch
            {
                MessageBox.Show("Sumtin went wong");
            }
        }
        private async void getpopular()
        {
            try
            {
                flowLayoutPanel2.Controls.Clear();
                HttpResponseMessage response = await httpclientthingy.GetAsync("https://scriptblox.com/api/script/fetch?page=1");
                HttpContent content = response.Content;
                object dynJson = JsonConvert.DeserializeObject(await content.ReadAsStringAsync());
                foreach (dynamic item in ((dynamic)dynJson).result.scripts)
                {
                    dynamic jsonitem = JsonConvert.DeserializeObject<object>(((object)item).ToString());
                    dynamic script = Convert.ToString(jsonitem.script);
                    dynamic dastitle = Convert.ToString(jsonitem.title);
                    dynamic descthingy = Convert.ToString(jsonitem.slug);
                    flowLayoutPanel2.Controls.Add(new Script(dastitle, script));
                }
            }
            catch
            {
                MessageBox.Show("Sumtin went wong");
            }
        }
        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            if(guna2Button5.Checked == true)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void tabPage1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if(docs.Visible == true)
            {
                docs.Visible = false;
                editor.Width = editor.Width + docs.Width;
            }
            else
            {
                docs.Visible = true;
                editor.Width = executor.Width - docs.Width;
            }
        }

        private void guna2TextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                getscripts();
            }
        }

        private async void pictureBox1_Click_1(object sender, EventArgs e)
        {
            currentPage = currentPage - 1;
            try
            {
                flowLayoutPanel2.Controls.Clear();
                HttpResponseMessage response = await httpclientthingy.GetAsync($"https://scriptblox.com/api/script/fetch?page={currentPage}");
                HttpContent content = response.Content;
                object dynJson = JsonConvert.DeserializeObject(await content.ReadAsStringAsync());
                foreach (dynamic item in ((dynamic)dynJson).result.scripts)
                {
                    dynamic jsonitem = JsonConvert.DeserializeObject<object>(((object)item).ToString());
                    dynamic script = Convert.ToString(jsonitem.script);
                    dynamic dastitle = Convert.ToString(jsonitem.title);
                    dynamic descthingy = Convert.ToString(jsonitem.slug);
                    flowLayoutPanel2.Controls.Add(new Script(dastitle, script));
                }
            }
            catch
            {
                MessageBox.Show("Sumtin went wong");
            }
        }

        private async void pictureBox2_Click(object sender, EventArgs e)
        {
            currentPage = currentPage + 1;
            try
            {
                flowLayoutPanel2.Controls.Clear();
                HttpResponseMessage response = await httpclientthingy.GetAsync($"https://scriptblox.com/api/script/fetch?page={currentPage}");
                HttpContent content = response.Content;
                object dynJson = JsonConvert.DeserializeObject(await content.ReadAsStringAsync());
                foreach (dynamic item in ((dynamic)dynJson).result.scripts)
                {
                    dynamic jsonitem = JsonConvert.DeserializeObject<object>(((object)item).ToString());
                    dynamic script = Convert.ToString(jsonitem.script);
                    dynamic dastitle = Convert.ToString(jsonitem.title);
                    dynamic descthingy = Convert.ToString(jsonitem.slug);
                    flowLayoutPanel2.Controls.Add(new Script(dastitle, script));
                }
            }
            catch
            {
                MessageBox.Show("Sumtin went wong");
            }
        }

        private void settingtoggle_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        private void guna2Button8_Click(object sender, EventArgs e)
        {
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            ProcessStartInfo startInfo1 = new ProcessStartInfo
            {
                FileName = "loader.exe",
            };
            startInfo1.WindowStyle = ProcessWindowStyle.Hidden;
            Process.Start(startInfo1);
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            WriteScript("",true);
        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = "lua";
            bool? nullable = openFileDialog.ShowDialog() == DialogResult.OK;
            bool flag = true;
            if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
                return;
            string str = File.ReadAllText(openFileDialog.FileName);
            this.WriteScript(str, false);
        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Directory.GetCurrentDirectory() + "\\Scripts";
            saveFileDialog.DefaultExt = "lua";
            saveFileDialog.Filter = "Lua files (*.lua)|*.lua";
            bool? nullable = saveFileDialog.ShowDialog() == DialogResult.OK;
            bool flag = true;
            if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
                return;
            File.WriteAllText(saveFileDialog.FileName, this.ReadScript());
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
