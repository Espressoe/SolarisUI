﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Solaris
{
    public partial class Script : UserControl
    {
        private static ClientWebSocket websocket;
        public Script(string name, string script)
        {
            InitializeComponent();
            label1.Text = name;
            pictureBox3.Click += delegate
            {
                Clipboard.SetText(script);
            };
            pictureBox2.Click += delegate
            {
                _ = Execute(script);
            };
        }
        public static async Task Execute(string code)
        {
            await Connect();
            byte[] buffer = Encoding.UTF8.GetBytes("<SCRIPT>" + code);
            await websocket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
        }
        static async Task Connect()
        {
            string loginToken = "LVFRQQD1EVLZWW";

            Uri uri = new Uri($"wss://loader.live/?login_token=\"{loginToken}\"");

            websocket = new ClientWebSocket();
            await websocket.ConnectAsync(uri, CancellationToken.None);
        }
        private void Script_MouseEnter(object sender, EventArgs e)
        {

        }
    }
}
